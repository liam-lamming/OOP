package src;


public class TranslationAction {
    public void translateTextLog(TextLog log) {
        log.translateContent();
    }
}
